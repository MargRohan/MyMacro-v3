# MyMacro v3

Browser extension source code for MyMacro v3.

## Project structure
- `manifest.json` — Chrome extension manifest (Manifest V2)
- `bg.js`, `bg.html` — background page
- `panel.js`, `panel.html` — main extension panel
- `content_scripts/` — page-side recorder/player/connector scripts
- `editor/` — macro editor
- `vendor/` — bundled third-party libraries
- `skin/` — UI assets
- `samples/` — sample macro files

## For Claude
Use this repository as the complete source code for the MyMacro v3 browser extension. Before changing code, inspect `manifest.json` and trace the relevant code path across background scripts, content scripts, UI, and editor files. Preserve existing functionality unless a change explicitly requires it.

## Important
This project uses Chrome Manifest V2. Some APIs or behaviors may require adaptation for modern Chrome/Chromium versions.
